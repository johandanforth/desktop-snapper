﻿using System;
using System.Diagnostics;
using System.Text;
using System.Collections.Generic;
using Irm.Tim.Snapper.Util;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Irm.Tim.Snapper.Tests
{
    [TestClass]
    public class CalendarUnitTests
    {

        [TestMethod]
        public void TestMethod1()
        {
            var datestring = "2011-03-11";
            var date = DateTime.Parse(datestring);
        }
    }
}
