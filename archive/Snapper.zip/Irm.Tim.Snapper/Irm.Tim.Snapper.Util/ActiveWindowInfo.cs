﻿using System.Drawing;

namespace Irm.Tim.Snapper.Util
{
    public class ActiveWindowInfo
    {
        public string ActiveProgramTitle { get; set; }
        public Rectangle Bounds { get; set; }
    }
}